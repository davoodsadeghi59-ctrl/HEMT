# HEMT-AI Framework

Physics-Guided Artificial Intelligence Framework for AlGaN/GaN MOS-HEMT Biosensors

Version: 1.0.0

Author:
AmirReza Sadeghi

Status:
Under Development