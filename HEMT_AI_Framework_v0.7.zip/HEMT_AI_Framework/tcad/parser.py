"""
===========================================================
parser.py

Raw Silvaco TCAD LOG file reader.

Author : AmirReza Sadeghi
===========================================================
"""

from pathlib import Path
from typing import List, Union

from config import get_logger

logger = get_logger(__name__)


class LogParser:
    """Read raw text lines from a Silvaco TCAD ``.log`` file."""

    def __init__(self, filepath: Union[str, Path]) -> None:
        """Initialize the parser.

        Args:
            filepath: Path to the ``.log`` file to read.
        """
        self.filepath = Path(filepath)

    def exists(self) -> bool:
        """Return whether the log file exists on disk."""
        return self.filepath.exists()

    def read(self) -> List[str]:
        """Read every line of the log file.

        Returns:
            The raw lines of the file, in order.

        Raises:
            FileNotFoundError: If ``self.filepath`` does not exist.
        """
        if not self.exists():
            raise FileNotFoundError(f"File not found:\n{self.filepath}")

        try:
            with open(self.filepath, "r", encoding="utf-8", errors="ignore") as file:
                lines = file.readlines()
        except OSError as exc:
            logger.error("Failed to read log file %s: %s", self.filepath, exc)
            raise

        logger.debug("Read %d lines from %s", len(lines), self.filepath.name)

        return lines


if __name__ == "__main__":
    from config import RAW_LOG_DIR

    logfile = sorted(RAW_LOG_DIR.glob("*.log"))[0]

    parser = LogParser(logfile)
    lines = parser.read()

    print("Number of lines:", len(lines))
    print(lines[:10])
