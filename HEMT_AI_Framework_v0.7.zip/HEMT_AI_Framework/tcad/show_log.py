"""
===========================================================
show_log.py

Debug utility: print every line of a Silvaco TCAD LOG file
with its line number.

Usage:
    python -m tcad.show_log [path/to/file.log]

If no path is given, the first file found in RAW_LOG_DIR is
used.

Author : AmirReza Sadeghi
===========================================================
"""

import sys
from pathlib import Path

from config import RAW_LOG_DIR
from tcad.parser import LogParser


def main() -> None:
    """Print every line of a chosen (or default) log file."""
    if len(sys.argv) > 1:
        logfile = Path(sys.argv[1])
    else:
        logfile = sorted(RAW_LOG_DIR.glob("*.log"))[0]

    lines = LogParser(logfile).read()

    for i, line in enumerate(lines):
        print(f"{i:03d} : {line.rstrip()}")


if __name__ == "__main__":
    main()
