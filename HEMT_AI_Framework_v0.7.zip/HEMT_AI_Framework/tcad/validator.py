"""
===========================================================
validator.py

Dataset Validator

Runs sanity checks on the built HEMT dataset (missing
values, duplicate rows, physical ranges) and returns a
structured report that downstream modules (e.g. the thesis
report generator) can consume, in addition to logging a
human-readable summary.

Author : AmirReza Sadeghi
===========================================================
"""

from typing import Any, Dict

import pandas as pd

from config import get_logger

logger = get_logger(__name__)

_REQUIRED_COLUMNS = ("IDS", "VGS", "EPS", "QF")


class DatasetValidator:
    """Validate a built HEMT dataset and report basic quality metrics."""

    def __init__(self, df: pd.DataFrame) -> None:
        """Initialize the validator.

        Args:
            df: The dataset to validate.
        """
        self.df = df

    def validate(self) -> Dict[str, Any]:
        """Run all validation checks.

        Returns:
            A dict summarizing missing values, duplicate rows,
            dataset shape, and value ranges for IDS/VGS/EPS/QF.

        Raises:
            ValueError: If a required column is missing.
        """
        missing_cols = [c for c in _REQUIRED_COLUMNS if c not in self.df.columns]
        if missing_cols:
            raise ValueError(f"Dataset is missing required columns: {missing_cols}")

        report = {
            "shape": self.df.shape,
            "missing_values": int(self.df.isnull().sum().sum()),
            "duplicate_rows": int(self.df.duplicated().sum()),
            "ids_min": float(self.df["IDS"].min()),
            "ids_max": float(self.df["IDS"].max()),
            "ids_mean": float(self.df["IDS"].mean()),
            "vgs_min": float(self.df["VGS"].min()),
            "vgs_max": float(self.df["VGS"].max()),
            "eps_values": sorted(self.df["EPS"].unique().tolist()),
            "qf_values": sorted(self.df["QF"].unique().tolist()),
        }

        logger.info("Dataset shape       : %s", report["shape"])
        logger.info("Missing values      : %d", report["missing_values"])
        logger.info("Duplicate rows      : %d", report["duplicate_rows"])
        logger.info(
            "IDS range           : min=%.6g max=%.6g mean=%.6g",
            report["ids_min"],
            report["ids_max"],
            report["ids_mean"],
        )
        logger.info("VGS range           : min=%.4g max=%.4g", report["vgs_min"], report["vgs_max"])
        logger.info("Unique EPS values   : %d", len(report["eps_values"]))
        logger.info("Unique QF values    : %d", len(report["qf_values"]))

        if report["missing_values"] > 0:
            logger.warning("Dataset contains %d missing values.", report["missing_values"])
        if report["duplicate_rows"] > 0:
            logger.warning("Dataset contains %d duplicate rows.", report["duplicate_rows"])

        logger.info("Validation finished.")

        return report
