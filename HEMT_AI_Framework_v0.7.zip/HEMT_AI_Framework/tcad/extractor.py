"""
===========================================================
extractor.py

Extract numeric I-V sweep records from parsed Silvaco TCAD
LOG lines (rows beginning with "d ").

Author : AmirReza Sadeghi
===========================================================
"""

from pathlib import Path
from typing import Union

import pandas as pd

from config import get_logger
from tcad.parser import LogParser

logger = get_logger(__name__)

# Column order matches the fixed layout of Silvaco "d " data rows.
DATA_COLUMNS = [
    "VDS",
    "VS",
    "IDS",
    "IG",
    "IS",
    "IB",
    "VG",
    "VG_Internal",
    "VSUB",
    "VGS",
    "VG_Applied",
    "Reserved",
]


class DataExtractor:
    """Extract the numeric sweep table from a Silvaco TCAD LOG file."""

    def __init__(self, logfile: Union[str, Path]) -> None:
        """Initialize the extractor.

        Args:
            logfile: Path to the ``.log`` file to extract data from.
        """
        self.logfile = Path(logfile)
        self.lines = LogParser(logfile).read()

    def extract(self) -> pd.DataFrame:
        """Parse every "d "-prefixed row into a numeric DataFrame.

        Returns:
            A DataFrame with columns :data:`DATA_COLUMNS`.

        Raises:
            ValueError: If a "d " row cannot be parsed as floats.
        """
        records = []

        for line_number, line in enumerate(self.lines, start=1):
            if not line.startswith("d "):
                continue

            values = line.split()[1:]

            try:
                values = [float(x) for x in values]
            except ValueError as exc:
                raise ValueError(
                    f"Malformed data row at line {line_number} in {self.logfile.name}: {line!r}"
                ) from exc

            records.append(values)

        df = pd.DataFrame(records, columns=DATA_COLUMNS)

        logger.debug("Extracted %d data rows from %s", len(df), self.logfile.name)

        return df


if __name__ == "__main__":
    from config import RAW_LOG_DIR

    logfile = sorted(RAW_LOG_DIR.glob("*.log"))[0]

    df = DataExtractor(logfile).extract()

    print(df.head())
    print()
    print(df.shape)
