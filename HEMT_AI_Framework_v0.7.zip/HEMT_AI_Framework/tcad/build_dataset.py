"""
===========================================================
build_dataset.py

Combine filename-encoded metadata (Structure, EPS, QF) with
the numeric sweep table extracted from a single Silvaco TCAD
LOG file into one tidy DataFrame.

Author : AmirReza Sadeghi
===========================================================
"""

from pathlib import Path
from typing import Union

import pandas as pd

from config import RAW_LOG_DIR, get_logger
from tcad.extractor import DataExtractor
from tcad.filename import FilenameParser

logger = get_logger(__name__)

_META_COLUMNS = ["Structure", "EPS", "QF"]


class DatasetBuilder:
    """Build a per-file tidy dataset from a Silvaco TCAD LOG file."""

    def __init__(self, logfile: Union[str, Path]) -> None:
        """Initialize the builder.

        Args:
            logfile: Path to the ``.log`` file to process.
        """
        self.logfile = Path(logfile)

    def build(self) -> pd.DataFrame:
        """Parse metadata and sweep data, then merge into one DataFrame.

        Returns:
            A DataFrame with ``Structure``, ``EPS``, ``QF`` as the
            first three columns, followed by the extracted sweep
            columns.
        """
        meta = FilenameParser(self.logfile).parse()
        df = DataExtractor(self.logfile).extract()

        df["Structure"] = meta["structure"]
        df["EPS"] = meta["eps"]
        df["QF"] = meta["qf"]

        ordered_columns = _META_COLUMNS + [c for c in df.columns if c not in _META_COLUMNS]

        logger.debug("Built %d samples from %s", len(df), self.logfile.name)

        return df[ordered_columns]


if __name__ == "__main__":
    logfile = sorted(RAW_LOG_DIR.glob("*.log"))[0]

    df = DatasetBuilder(logfile).build()

    print(df.head())
    print()
    print(df.shape)
