"""
===========================================================
filename.py

Parse simulation parameters (Structure, EPS, QF) encoded in
a Silvaco TCAD LOG filename.

Author : AmirReza Sadeghi
===========================================================
"""

import re
from pathlib import Path
from typing import Dict, Union

from config import get_logger

logger = get_logger(__name__)


class FilenameParser:
    """Parse simulation parameters from a LOG filename.

    Supported formats
    -----------------
    ``S01_eps80_q7.5e12.log``  (explicit structure id)
    ``eps80_q7.5e12.log``      (structure defaults to 1)
    """

    _PATTERN_OLD = re.compile(
        r"S(?P<structure>\d+)_eps(?P<eps>[0-9.]+)_q(?P<qf>[0-9.eE+-]+)"
    )
    _PATTERN_NEW = re.compile(r"eps(?P<eps>[0-9.]+)_q(?P<qf>[0-9.eE+-]+)")

    def __init__(self, filepath: Union[str, Path]) -> None:
        """Initialize the parser.

        Args:
            filepath: Path (or bare filename) to parse.
        """
        self.filepath = Path(filepath)

    def parse(self) -> Dict[str, float]:
        """Extract ``structure``, ``eps``, and ``qf`` from the filename.

        Returns:
            A dict with keys ``structure`` (int), ``eps`` (float),
            and ``qf`` (float).

        Raises:
            ValueError: If the filename matches neither supported
                naming convention.
        """
        name = self.filepath.stem

        match = self._PATTERN_OLD.match(name)
        if match:
            return {
                "structure": int(match.group("structure")),
                "eps": float(match.group("eps")),
                "qf": float(match.group("qf")),
            }

        match = self._PATTERN_NEW.match(name)
        if match:
            return {
                "structure": 1,
                "eps": float(match.group("eps")),
                "qf": float(match.group("qf")),
            }

        logger.error("Filename does not match a known naming convention: %s", name)
        raise ValueError(f"Invalid filename:\n{name}")


if __name__ == "__main__":
    tests = ["S01_eps80_q7.5e12.log", "eps10_q1e11.log"]

    for f in tests:
        print(FilenameParser(f).parse())
