"""
=========================================================
run_pipeline.py

Main pipeline for HEMT AI Framework

Author : AmirReza Sadeghi
=========================================================
"""
from tcad.validator import DatasetValidator
import pandas as pd

from config import RAW_LOG_DIR, DATASET_DIR
from tcad.build_dataset import DatasetBuilder


def main():

    # --------------------------------------------------
    # پیدا کردن تمام فایل‌های LOG
    # --------------------------------------------------
    log_files = sorted(RAW_LOG_DIR.glob("*.log"))

    if len(log_files) == 0:
        print("No LOG files found.")
        return

    print("=" * 60)
    print("HEMT AI FRAMEWORK")
    print("=" * 60)

    print(f"\nFound {len(log_files)} LOG files.\n")

    datasets = []

    # --------------------------------------------------
    # پردازش تک تک فایل‌ها
    # --------------------------------------------------
    for i, logfile in enumerate(log_files, start=1):

        print(f"[{i}/{len(log_files)}] Processing: {logfile.name}")

        builder = DatasetBuilder(logfile)

        df = builder.build()

        datasets.append(df)

    # --------------------------------------------------
    # ادغام همه DataFrameها
    # --------------------------------------------------
    final_dataset = pd.concat(
        datasets,
        ignore_index=True
    )

    # --------------------------------------------------
    # ذخیره Dataset
    # --------------------------------------------------
    output_file = DATASET_DIR / "hemt_dataset.csv"

    final_dataset.to_csv(
        output_file,
        index=False
    )
    validator = DatasetValidator(final_dataset)

    validator.validate()
    # --------------------------------------------------
    # گزارش
    # --------------------------------------------------
    print("\n" + "=" * 60)
    print("PIPELINE FINISHED SUCCESSFULLY")
    print("=" * 60)

    print(f"\nDataset Shape : {final_dataset.shape}")

    print(f"\nColumns : {len(final_dataset.columns)}")

    print("\nFirst 5 Samples:\n")

    print(final_dataset.head())

    print(f"\nDataset saved to:\n{output_file}")

    print("\nDone.")


if __name__ == "__main__":
    main()