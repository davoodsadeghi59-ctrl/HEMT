"""
=========================================================
inspect_logs.py

Inspect every TCAD LOG file

Author : AmirReza Sadeghi
=========================================================
"""

from config import RAW_LOG_DIR
from tcad.build_dataset import DatasetBuilder


def main():

    print("=" * 80)
    print("TCAD LOG INSPECTION")
    print("=" * 80)

    log_files = sorted(RAW_LOG_DIR.glob("*.log"))

    for logfile in log_files:

        df = DatasetBuilder(logfile).build()

        print("\n" + "-" * 80)
        print(logfile.name)
        print("-" * 80)

        print(f"Samples        : {len(df)}")
        print(f"VGS Range      : {df['VGS'].min()}  --->  {df['VGS'].max()}")
        print(f"Unique VGS     : {df['VGS'].nunique()}")

        print(f"IDS Min        : {df['IDS'].min():.6f}")
        print(f"IDS Max        : {df['IDS'].max():.6f}")

        print(f"Missing Values : {df.isnull().sum().sum()}")
        print(f"Duplicates     : {df.duplicated().sum()}")

        # بررسی یکنواخت بودن گام‌های VGS
        step = df["VGS"].diff().dropna()

        if len(step) > 0:
            print(f"Average Step   : {step.mean():.6f}")
            print(f"Min Step       : {step.min():.6f}")
            print(f"Max Step       : {step.max():.6f}")

    print("\n" + "=" * 80)
    print("Inspection Finished")
    print("=" * 80)


if __name__ == "__main__":
    main()