"""
=========================================================
dataset_report.py

Dataset Quality Report

Author : AmirReza Sadeghi
=========================================================
"""

import pandas as pd

from config import DATASET_DIR


def main():

    dataset = DATASET_DIR / "hemt_dataset.csv"

    df = pd.read_csv(dataset)

    print("=" * 60)
    print("HEMT DATASET REPORT")
    print("=" * 60)

    print(f"\nNumber of Samples : {len(df)}")
    print(f"Number of Columns : {len(df.columns)}")

    print("\nColumns")
    print("-" * 60)

    for c in df.columns:
        print(c)

    print("\nStructures")
    print("-" * 60)
    print(sorted(df["Structure"].unique()))

    print("\nEPS values")
    print("-" * 60)
    print(sorted(df["EPS"].unique()))

    print("\nQF values")
    print("-" * 60)
    print(sorted(df["QF"].unique()))

    print("\nMissing Values")
    print("-" * 60)
    print(df.isnull().sum())

    print("\nDuplicate Rows")
    print("-" * 60)
    print(df.duplicated().sum())

    print("\nStatistics")
    print("-" * 60)
    print(df.describe())

    print("\nSamples per Structure")
    print("-" * 60)
    print(df.groupby("Structure").size())

    print("\nSamples per QF")
    print("-" * 60)
    print(df.groupby("QF").size())


if __name__ == "__main__":

    main()