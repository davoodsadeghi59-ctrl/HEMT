"""
=========================================================
sample_counter.py
=========================================================
"""

from pathlib import Path

from config import RAW_LOG_DIR
from tcad.build_dataset import DatasetBuilder


def main():

    print("=" * 60)
    print("SAMPLES PER LOG FILE")
    print("=" * 60)

    total = 0

    log_files = sorted(RAW_LOG_DIR.glob("*.log"))

    for logfile in log_files:

        df = DatasetBuilder(logfile).build()

        n = len(df)

        total += n

        print(f"{logfile.name:30s} {n:5d}")

    print("-" * 60)

    print(f"TOTAL = {total}")


if __name__ == "__main__":

    main()