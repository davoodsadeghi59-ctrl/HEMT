"""
===========================================================
ann.py

Artificial Neural Network Model
HEMT AI Framework

Builds the fully connected regression ANN used to predict
IDS from (EPS, QF, VGS). All hyperparameters come from
ml/config.py so architecture changes happen in one place.

Author : AmirReza Sadeghi
===========================================================
"""

from typing import Sequence

import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import BatchNormalization, Dense, Dropout
from tensorflow.keras.optimizers import Adam

from config import get_logger
from ml.config import (
    ACTIVATION,
    DROPOUT_RATE,
    HIDDEN_LAYERS,
    LEARNING_RATE,
    LOSS,
    METRICS,
    OUTPUT_ACTIVATION,
    OUTPUT_DIM,
    USE_BATCH_NORM,
)

logger = get_logger(__name__)


def build_model(input_dim: int = 3, hidden_layers: Sequence[int] = HIDDEN_LAYERS) -> tf.keras.Model:
    """Build and compile the HEMT IDS-regression ANN.

    Architecture: a stack of Dense hidden layers (sizes taken
    from ``hidden_layers``), each optionally followed by
    BatchNormalization and Dropout, ending in a single linear
    output unit for the regression target (IDS).

    Args:
        input_dim: Number of input features (EPS, QF, VGS -> 3).
        hidden_layers: Units per hidden Dense layer, in order.
            Defaults to ``ml.config.HIDDEN_LAYERS``.

    Returns:
        A compiled ``tf.keras.Model`` ready for training.
    """
    logger.info(
        "Building ANN | input_dim=%d hidden_layers=%s dropout=%.2f batch_norm=%s",
        input_dim,
        hidden_layers,
        DROPOUT_RATE,
        USE_BATCH_NORM,
    )

    layers = [Dense(hidden_layers[0], activation=ACTIVATION, input_shape=(input_dim,))]

    for units in hidden_layers[1:]:
        if USE_BATCH_NORM:
            layers.append(BatchNormalization())
        if DROPOUT_RATE > 0:
            layers.append(Dropout(DROPOUT_RATE))
        layers.append(Dense(units, activation=ACTIVATION))

    layers.append(Dense(OUTPUT_DIM, activation=OUTPUT_ACTIVATION))

    model = Sequential(layers)

    model.compile(
        optimizer=Adam(learning_rate=LEARNING_RATE),
        loss=LOSS,
        metrics=METRICS,
    )

    return model


if __name__ == "__main__":
    build_model().summary()
