"""
===========================================================
evaluate.py

Evaluate the trained ANN Model

Loads the best model, predicts on the (scaled) test split,
inverse-transforms predictions back to physical IDS, computes
MAE / RMSE / MAPE / R^2, and saves a prediction table plus
diagnostic plots (prediction-vs-actual, residuals).

Author : AmirReza Sadeghi
===========================================================
"""

from typing import Dict

import joblib
import matplotlib
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error, mean_squared_error, r2_score
from tensorflow.keras.models import load_model

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from config import (
    BEST_MODEL_PATH,
    FIGURE_DPI,
    FIGURE_FACECOLOR,
    PROCESSED_DIR,
    RESULTS_DIR,
    Y_SCALER_PATH,
    get_logger,
)

logger = get_logger(__name__)


def evaluate_model(
    model_path=BEST_MODEL_PATH,
    processed_dir=PROCESSED_DIR,
    y_scaler_path=Y_SCALER_PATH,
    results_dir=RESULTS_DIR,
) -> Dict[str, float]:
    """Evaluate the trained model on the held-out test split.

    Args:
        model_path: Path to the trained ``.keras`` model.
        processed_dir: Directory with the scaled test split.
        y_scaler_path: Path to the fitted target scaler.
        results_dir: Directory to save the prediction table and plots.

    Returns:
        A dict with keys ``mae``, ``mse``, ``rmse``, ``mape``, ``r2``.

    Raises:
        FileNotFoundError: If the model or required data files are missing.
    """
    for required in (model_path, y_scaler_path):
        if not required.exists():
            raise FileNotFoundError(f"Required artifact not found: {required}")

    results_dir.mkdir(parents=True, exist_ok=True)

    logger.info("Loading model from %s", model_path)
    model = load_model(model_path)

    X_test = pd.read_csv(processed_dir / "X_test_scaled.csv")
    y_test = pd.read_csv(processed_dir / "y_test.csv").values.ravel()

    logger.info("Predicting on test set (%d samples)", len(X_test))
    y_pred_scaled = model.predict(X_test, verbose=0).flatten()

    y_scaler = joblib.load(y_scaler_path)
    y_pred = y_scaler.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()

    metrics = {
        "mae": float(mean_absolute_error(y_test, y_pred)),
        "mse": float(mean_squared_error(y_test, y_pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_test, y_pred))),
        "mape": float(mean_absolute_percentage_error(y_test, y_pred)),
        "r2": float(r2_score(y_test, y_pred)),
    }

    logger.info(
        "MAE=%.8f  RMSE=%.8f  MAPE=%.4f%%  R2=%.6f",
        metrics["mae"],
        metrics["rmse"],
        metrics["mape"] * 100,
        metrics["r2"],
    )

    results = pd.DataFrame(
        {"Actual_IDS": y_test, "Predicted_IDS": y_pred, "Residual": y_pred - y_test}
    )
    results.to_csv(results_dir / "prediction_results.csv", index=False)

    _plot_prediction_vs_actual(y_test, y_pred, results_dir)
    _plot_residuals(y_test, y_pred, results_dir)

    logger.info("Evaluation artifacts saved to %s", results_dir)

    return metrics


def _plot_prediction_vs_actual(y_test, y_pred, results_dir) -> None:
    fig = plt.figure(figsize=(6, 6), facecolor=FIGURE_FACECOLOR)
    plt.scatter(y_test, y_pred, alpha=0.7)
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], "r--")
    plt.xlabel("Actual IDS")
    plt.ylabel("Predicted IDS")
    plt.title("Prediction vs Actual")
    plt.grid(True)
    plt.tight_layout()
    fig.savefig(results_dir / "prediction_vs_actual.png", dpi=FIGURE_DPI, facecolor=FIGURE_FACECOLOR)
    plt.close(fig)


def _plot_residuals(y_test, y_pred, results_dir) -> None:
    residuals = y_pred - y_test
    fig = plt.figure(figsize=(6, 4), facecolor=FIGURE_FACECOLOR)
    plt.scatter(y_pred, residuals, alpha=0.7)
    plt.axhline(0, color="red", linestyle="--")
    plt.xlabel("Predicted IDS")
    plt.ylabel("Residual")
    plt.title("Residual Plot")
    plt.grid(True)
    plt.tight_layout()
    fig.savefig(results_dir / "residual_plot.png", dpi=FIGURE_DPI, facecolor=FIGURE_FACECOLOR)
    plt.close(fig)


def main() -> None:
    """CLI entry point: run evaluation."""
    evaluate_model()


if __name__ == "__main__":
    main()
