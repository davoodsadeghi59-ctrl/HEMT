"""
===========================================================
train.py

Train the ANN Model

Loads the scaled train/validation splits, builds the ANN
(models.ann.build_model, configured via ml/config.py),
trains it with EarlyStopping / ReduceLROnPlateau /
ModelCheckpoint, and saves the best model + training history.

Author : AmirReza Sadeghi
===========================================================
"""

import pandas as pd
import tensorflow as tf
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau

from config import BEST_MODEL_PATH, PROCESSED_DIR, RANDOM_SEED, TRAINING_HISTORY_PATH, get_logger
from ml.config import (
    BATCH_SIZE,
    EPOCHS,
    PATIENCE,
    REDUCE_LR_FACTOR,
    REDUCE_LR_PATIENCE,
    RESTORE_BEST_WEIGHTS,
)
from models.ann import build_model

logger = get_logger(__name__)


def _load_split(processed_dir, name: str) -> pd.DataFrame:
    path = processed_dir / f"{name}.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run ml.split and ml.scaler / ml.y_scaler first."
        )
    return pd.read_csv(path)


def train_model(
    processed_dir=PROCESSED_DIR,
    model_path=BEST_MODEL_PATH,
    history_path=TRAINING_HISTORY_PATH,
) -> tf.keras.callbacks.History:
    """Train the HEMT ANN and persist the best model + history.

    Args:
        processed_dir: Directory containing the scaled splits.
        model_path: Where to save the best model checkpoint.
        history_path: Where to save the training history CSV.

    Returns:
        The Keras ``History`` object returned by ``model.fit``.
    """
    tf.random.set_seed(RANDOM_SEED)

    X_train = _load_split(processed_dir, "X_train_scaled")
    X_valid = _load_split(processed_dir, "X_valid_scaled")
    y_train = _load_split(processed_dir, "y_train_scaled").values.ravel()
    y_valid = _load_split(processed_dir, "y_valid_scaled").values.ravel()

    model = build_model(input_dim=X_train.shape[1])

    callbacks = [
        EarlyStopping(
            monitor="val_loss",
            patience=PATIENCE,
            restore_best_weights=RESTORE_BEST_WEIGHTS,
        ),
        ReduceLROnPlateau(
            monitor="val_loss",
            factor=REDUCE_LR_FACTOR,
            patience=REDUCE_LR_PATIENCE,
            verbose=1,
        ),
        ModelCheckpoint(
            filepath=str(model_path),
            monitor="val_loss",
            save_best_only=True,
        ),
    ]

    logger.info("Training started | epochs=%d batch_size=%d", EPOCHS, BATCH_SIZE)

    history = model.fit(
        X_train,
        y_train,
        validation_data=(X_valid, y_valid),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=callbacks,
        verbose=1,
    )

    pd.DataFrame(history.history).to_csv(history_path, index=False)

    logger.info("Training finished. Best model saved to %s", model_path)
    logger.info("History saved to %s", history_path)

    return history


def main() -> None:
    """CLI entry point: train the model."""
    train_model()


if __name__ == "__main__":
    main()
