"""
===========================================================
scaler.py

Scale Train / Validation / Test feature sets with a
StandardScaler fit on the training split only, and persist
the fitted scaler for later inverse-transforms and
inference-time use.

Author : AmirReza Sadeghi
===========================================================
"""

import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler

from config import MODEL_ARTIFACT_DIR, PROCESSED_DIR, X_SCALER_PATH, get_logger

logger = get_logger(__name__)


class DatasetScaler:
    """Fit a StandardScaler on X_train and apply it to all splits."""

    def __init__(self, processed_dir=PROCESSED_DIR, scaler_dir=MODEL_ARTIFACT_DIR) -> None:
        """Initialize the scaler.

        Args:
            processed_dir: Directory containing X_train/X_valid/X_test CSVs.
            scaler_dir: Directory to persist the fitted scaler into.
        """
        self.processed = processed_dir
        self.model_dir = scaler_dir
        self.model_dir.mkdir(parents=True, exist_ok=True)

    def scale(self) -> StandardScaler:
        """Fit on X_train and transform X_train/X_valid/X_test.

        Returns:
            The fitted :class:`~sklearn.preprocessing.StandardScaler`.

        Raises:
            FileNotFoundError: If any required split CSV is missing.
        """
        required = ["X_train.csv", "X_valid.csv", "X_test.csv"]
        missing = [f for f in required if not (self.processed / f).exists()]
        if missing:
            raise FileNotFoundError(
                f"Missing split file(s) {missing} in {self.processed}. Run ml.split first."
            )

        X_train = pd.read_csv(self.processed / "X_train.csv")
        X_valid = pd.read_csv(self.processed / "X_valid.csv")
        X_test = pd.read_csv(self.processed / "X_test.csv")

        scaler = StandardScaler()

        X_train_scaled = scaler.fit_transform(X_train)
        X_valid_scaled = scaler.transform(X_valid)
        X_test_scaled = scaler.transform(X_test)

        pd.DataFrame(X_train_scaled, columns=X_train.columns).to_csv(
            self.processed / "X_train_scaled.csv", index=False
        )
        pd.DataFrame(X_valid_scaled, columns=X_valid.columns).to_csv(
            self.processed / "X_valid_scaled.csv", index=False
        )
        pd.DataFrame(X_test_scaled, columns=X_test.columns).to_csv(
            self.processed / "X_test_scaled.csv", index=False
        )

        joblib.dump(scaler, X_SCALER_PATH)

        logger.info("Features scaled : %s", X_train.columns.tolist())
        logger.info("Train shape      : %s", X_train_scaled.shape)
        logger.info("Validation shape : %s", X_valid_scaled.shape)
        logger.info("Test shape       : %s", X_test_scaled.shape)
        logger.info("Scaler saved to  : %s", X_SCALER_PATH)

        return scaler


def main() -> None:
    """CLI entry point: run feature scaling."""
    DatasetScaler().scale()


if __name__ == "__main__":
    main()
