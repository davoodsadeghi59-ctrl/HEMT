"""
===========================================================
ml/config.py

Machine Learning Configuration

Hyperparameters for the ANN architecture and training loop.
Paths live in the top-level config.py; this file only holds
model/training hyperparameters so both are imported from one
place instead of being hard-coded inside models/ann.py or
models/train.py.

Author : AmirReza Sadeghi
===========================================================
"""

from config import RANDOM_SEED

# -------------------------------------------------------
# Random Seed (single source of truth: config.RANDOM_SEED)
# -------------------------------------------------------

RANDOM_STATE = RANDOM_SEED

# -------------------------------------------------------
# Neural Network Architecture
# -------------------------------------------------------

INPUT_DIM = 3  # EPS, QF, VGS

HIDDEN_LAYERS = (64, 32, 16)  # units per Dense hidden layer, in order

DROPOUT_RATE = 0.20
USE_BATCH_NORM = True

OUTPUT_DIM = 1

ACTIVATION = "relu"
OUTPUT_ACTIVATION = "linear"

# -------------------------------------------------------
# Training
# -------------------------------------------------------

EPOCHS = 300

BATCH_SIZE = 32

LEARNING_RATE = 0.001

LOSS = "mse"

METRICS = ["mae"]

# -------------------------------------------------------
# Early Stopping / LR Schedule
# -------------------------------------------------------

EARLY_STOPPING = True

PATIENCE = 30

RESTORE_BEST_WEIGHTS = True

REDUCE_LR_FACTOR = 0.5

REDUCE_LR_PATIENCE = 10

# -------------------------------------------------------
# Model Saving
# -------------------------------------------------------

MODEL_NAME = "best_model.keras"

SCALER_NAME = "standard_scaler.pkl"

HISTORY_NAME = "training_history.csv"
