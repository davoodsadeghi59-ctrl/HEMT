"""
===========================================================
permutation.py

Permutation Feature Importance

Measures how much held-out MSE degrades when each feature is
independently shuffled, as a model-agnostic importance check
that complements the SHAP analysis.

Author : AmirReza Sadeghi
===========================================================
"""

from typing import Dict

import joblib
import matplotlib
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.inspection import permutation_importance
from tensorflow.keras.models import load_model

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from config import (
    BEST_MODEL_PATH,
    FIGURE_DPI,
    FIGURE_FACECOLOR,
    IMPORTANCE_DIR,
    PROCESSED_DIR,
    RANDOM_SEED,
    get_logger,
)

logger = get_logger(__name__)


class KerasPredictor(RegressorMixin, BaseEstimator):
    """Minimal sklearn-compatible wrapper around a trained Keras model.

    ``sklearn.inspection.permutation_importance`` expects a full
    sklearn estimator (including the ``__sklearn_tags__`` protocol
    introduced in newer scikit-learn versions), so this inherits from
    ``BaseEstimator``/``RegressorMixin`` rather than duck-typing
    ``fit``/``predict`` alone. The model is already trained, so
    ``fit`` is a no-op.
    """

    def __init__(self, model=None) -> None:
        self.model = model

    def fit(self, X, y=None):  # noqa: D102 - sklearn API compliance, no-op
        return self

    def predict(self, X):
        return self.model.predict(X, verbose=0).flatten()


def compute_permutation_importance(
    model_path=BEST_MODEL_PATH,
    processed_dir=PROCESSED_DIR,
    results_dir=IMPORTANCE_DIR,
    n_repeats: int = 20,
) -> pd.DataFrame:
    """Compute and save permutation feature importance for the ANN.

    Args:
        model_path: Path to the trained ``.keras`` model.
        processed_dir: Directory with the scaled test split.
        results_dir: Directory to save the importance CSV/plot.
        n_repeats: Number of shuffles per feature.

    Returns:
        A DataFrame with ``Feature``, ``Importance``, ``Std`` sorted
        by importance descending.
    """
    if not model_path.exists():
        raise FileNotFoundError(f"Model not found at {model_path}")

    results_dir.mkdir(parents=True, exist_ok=True)

    X_test = pd.read_csv(processed_dir / "X_test_scaled.csv")
    y_test = pd.read_csv(processed_dir / "y_test_scaled.csv").values.ravel()

    logger.info("Loading model from %s", model_path)
    model = load_model(model_path)
    predictor = KerasPredictor(model)

    logger.info("Computing permutation importance (n_repeats=%d)", n_repeats)
    result = permutation_importance(
        predictor,
        X_test,
        y_test,
        scoring="neg_mean_squared_error",
        n_repeats=n_repeats,
        random_state=RANDOM_SEED,
    )

    importance = pd.DataFrame(
        {
            "Feature": X_test.columns,
            "Importance": result.importances_mean,
            "Std": result.importances_std,
        }
    ).sort_values(by="Importance", ascending=False)

    importance.to_csv(results_dir / "permutation_importance.csv", index=False)

    fig = plt.figure(figsize=(6, 4), facecolor=FIGURE_FACECOLOR)
    plt.bar(importance["Feature"], importance["Importance"])
    plt.ylabel("Importance")
    plt.title("Permutation Importance")
    plt.grid(True)
    plt.tight_layout()
    fig.savefig(results_dir / "permutation_importance.png", dpi=FIGURE_DPI, facecolor=FIGURE_FACECOLOR)
    plt.close(fig)

    logger.info("Permutation importance:\n%s", importance.to_string(index=False))
    logger.info("Saved permutation importance artifacts to %s", results_dir)

    return importance


def main() -> None:
    """CLI entry point: run permutation importance analysis."""
    compute_permutation_importance()


if __name__ == "__main__":
    main()
