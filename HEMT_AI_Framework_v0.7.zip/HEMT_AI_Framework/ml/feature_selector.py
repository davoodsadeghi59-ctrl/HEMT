"""
===========================================================
feature_selector.py

Feature Selection for ANN

Drops constant, leakage, and redundant columns from the raw
HEMT dataset to produce the ML-ready dataset
(hemt_ml_dataset.csv).

Author : AmirReza Sadeghi
===========================================================
"""

from typing import List

import pandas as pd

from config import ML_DATASET_PATH, RAW_DATASET_PATH, get_logger

logger = get_logger(__name__)

# Columns that leak the target (derived from / co-measured with IDS)
# rather than being independent design inputs.
LEAKAGE_CANDIDATES = ["IB", "IS", "IG", "VG_Internal", "VG_Applied"]


class FeatureSelector:
    """Reduce the raw HEMT dataset to a clean ML-ready feature set."""

    def __init__(self, dataset_path=RAW_DATASET_PATH) -> None:
        """Initialize the selector by loading the raw dataset.

        Args:
            dataset_path: Path to the raw dataset CSV. Defaults to
                :data:`config.RAW_DATASET_PATH`.

        Raises:
            FileNotFoundError: If the dataset file does not exist.
        """
        if not dataset_path.exists():
            raise FileNotFoundError(
                f"Raw dataset not found at {dataset_path}. Run run_pipeline.py's "
                "dataset-build stage first."
            )

        self.df = pd.read_csv(dataset_path)

    def remove_constant_columns(self) -> List[str]:
        """Drop columns with a single unique value (zero information).

        Returns:
            The list of column names removed.
        """
        constant = [c for c in self.df.columns if self.df[c].nunique() == 1]
        self.df = self.df.drop(columns=constant)
        return constant

    def remove_leakage_columns(self) -> List[str]:
        """Drop columns that would leak the IDS target.

        Returns:
            The list of column names removed.
        """
        leakage = [c for c in LEAKAGE_CANDIDATES if c in self.df.columns]
        self.df = self.df.drop(columns=leakage)
        return leakage

    def remove_redundant_columns(self) -> List[str]:
        """Drop columns that exactly duplicate another retained column.

        Currently checks whether ``VG`` is identical to ``VGS``.

        Returns:
            The list of column names removed.
        """
        redundant = []

        if "VG" in self.df.columns and "VGS" in self.df.columns:
            if self.df["VG"].equals(self.df["VGS"]):
                redundant.append("VG")
                self.df = self.df.drop(columns=["VG"])

        return redundant

    def build_ml_dataset(self, output_path=ML_DATASET_PATH) -> pd.DataFrame:
        """Run all selection steps and save the resulting ML dataset.

        Args:
            output_path: Where to save the ML-ready dataset. Defaults
                to :data:`config.ML_DATASET_PATH`.

        Returns:
            The cleaned DataFrame.
        """
        constant = self.remove_constant_columns()
        leakage = self.remove_leakage_columns()
        redundant = self.remove_redundant_columns()

        output_path.parent.mkdir(parents=True, exist_ok=True)
        self.df.to_csv(output_path, index=False)

        logger.info("Removed constant columns  : %s", constant)
        logger.info("Removed leakage columns   : %s", leakage)
        logger.info("Removed redundant columns : %s", redundant)
        logger.info("Remaining columns         : %s", self.df.columns.tolist())
        logger.info("Final shape               : %s", self.df.shape)
        logger.info("Saved ML dataset to       : %s", output_path)

        return self.df


def main() -> None:
    """CLI entry point: build and save the ML-ready dataset."""
    FeatureSelector().build_ml_dataset()


if __name__ == "__main__":
    main()
