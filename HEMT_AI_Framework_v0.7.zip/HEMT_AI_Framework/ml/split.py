"""
===========================================================
split.py

Train / Validation / Test Split

Splits the ML-ready dataset 70/15/15 into train, validation,
and test sets and saves each to Data/processed.

Author : AmirReza Sadeghi
===========================================================
"""

from typing import Dict

import pandas as pd
from sklearn.model_selection import train_test_split

from config import ML_DATASET_PATH, PROCESSED_DIR, RANDOM_SEED, get_logger

logger = get_logger(__name__)


class DatasetSplitter:
    """Split the ML dataset into train/validation/test sets."""

    def __init__(self, dataset_path=ML_DATASET_PATH) -> None:
        """Initialize the splitter by loading the ML dataset.

        Args:
            dataset_path: Path to the ML-ready dataset CSV.

        Raises:
            FileNotFoundError: If the dataset file does not exist.
        """
        if not dataset_path.exists():
            raise FileNotFoundError(
                f"ML dataset not found at {dataset_path}. Run ml.feature_selector first."
            )

        self.df = pd.read_csv(dataset_path)

    def split(self, output_dir=PROCESSED_DIR) -> Dict[str, pd.DataFrame]:
        """Perform a 70/15/15 train/validation/test split and save to CSV.

        Args:
            output_dir: Directory to save the split CSV files into.

        Returns:
            A dict with keys ``X_train``, ``X_valid``, ``X_test``,
            ``y_train``, ``y_valid``, ``y_test``.
        """
        X = self.df.drop(columns=["IDS"])
        y = self.df["IDS"]

        X_train, X_temp, y_train, y_temp = train_test_split(
            X, y, test_size=0.30, random_state=RANDOM_SEED, shuffle=True
        )

        X_valid, X_test, y_valid, y_test = train_test_split(
            X_temp, y_temp, test_size=0.50, random_state=RANDOM_SEED, shuffle=True
        )

        output_dir.mkdir(parents=True, exist_ok=True)

        splits = {
            "X_train": X_train,
            "X_valid": X_valid,
            "X_test": X_test,
            "y_train": y_train,
            "y_valid": y_valid,
            "y_test": y_test,
        }

        for name, frame in splits.items():
            frame.to_csv(output_dir / f"{name}.csv", index=False)

        logger.info("Train samples      : %d", len(X_train))
        logger.info("Validation samples : %d", len(X_valid))
        logger.info("Test samples       : %d", len(X_test))
        logger.info("Saved splits to    : %s", output_dir)

        return splits


def main() -> None:
    """CLI entry point: run the split."""
    DatasetSplitter().split()


if __name__ == "__main__":
    main()
