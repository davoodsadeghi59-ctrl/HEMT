"""
===========================================================
preprocess.py

Machine Learning Data Preprocessing

Splits the ML-ready dataset into feature matrix X and
target vector y (IDS), dropping any leftover non-predictive
columns.

Author : AmirReza Sadeghi
===========================================================
"""

from typing import Tuple

import pandas as pd

from config import ML_DATASET_PATH, get_logger

logger = get_logger(__name__)

# Columns that may still be present but are not model inputs.
_NON_FEATURE_COLUMNS = ["Reserved", "VG_Internal", "VG_Applied"]


class DataPreprocessor:
    """Split the ML dataset into features (X) and target (y)."""

    def __init__(self, dataset_path=ML_DATASET_PATH) -> None:
        """Initialize the preprocessor by loading the ML dataset.

        Args:
            dataset_path: Path to the ML-ready dataset CSV.

        Raises:
            FileNotFoundError: If the dataset file does not exist.
        """
        if not dataset_path.exists():
            raise FileNotFoundError(
                f"ML dataset not found at {dataset_path}. Run ml.feature_selector first."
            )

        self.df = pd.read_csv(dataset_path)

    def prepare(self) -> Tuple[pd.DataFrame, pd.Series]:
        """Produce the (X, y) split.

        Returns:
            A tuple ``(X, y)`` where ``y`` is the IDS target and
            ``X`` is every remaining column.

        Raises:
            KeyError: If the dataset has no ``IDS`` column.
        """
        if "IDS" not in self.df.columns:
            raise KeyError("Dataset has no 'IDS' target column.")

        existing = [c for c in _NON_FEATURE_COLUMNS if c in self.df.columns]
        self.df = self.df.drop(columns=existing)

        y = self.df["IDS"]
        X = self.df.drop(columns=["IDS"])

        logger.info("Feature columns : %s", X.columns.tolist())
        logger.info("Feature shape   : %s", X.shape)
        logger.info("Target shape    : %s", y.shape)

        return X, y


def main() -> None:
    """CLI entry point: run preprocessing and log a preview."""
    X, y = DataPreprocessor().prepare()
    print(X.head())
    print()
    print(y.head())


if __name__ == "__main__":
    main()
