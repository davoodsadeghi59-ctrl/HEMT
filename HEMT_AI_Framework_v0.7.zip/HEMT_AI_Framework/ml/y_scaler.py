"""
===========================================================
y_scaler.py

Scale the IDS target (y_train / y_valid / y_test) with a
StandardScaler fit on the training split only, and persist
the fitted scaler so predictions can be inverse-transformed
back to physical IDS units.

NOTE (scientific flag, not changed here): IDS in this
dataset can span several orders of magnitude across the
EPS/QF design space. A linear StandardScaler is applied here
to preserve the existing, already-validated training
behavior; if a log-scale target transform is desired instead,
that is a modeling decision that should be made explicitly
and revalidated end-to-end, not changed silently.

Author : AmirReza Sadeghi
===========================================================
"""

import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler

from config import PROCESSED_DIR, Y_SCALER_PATH, get_logger

logger = get_logger(__name__)


class TargetScaler:
    """Fit a StandardScaler on y_train and apply it to all splits."""

    def __init__(self, processed_dir=PROCESSED_DIR) -> None:
        """Initialize the target scaler.

        Args:
            processed_dir: Directory containing y_train/y_valid/y_test CSVs.
        """
        self.processed = processed_dir

    def scale(self) -> StandardScaler:
        """Fit on y_train and transform y_train/y_valid/y_test.

        Returns:
            The fitted :class:`~sklearn.preprocessing.StandardScaler`.

        Raises:
            FileNotFoundError: If any required split CSV is missing.
        """
        required = ["y_train.csv", "y_valid.csv", "y_test.csv"]
        missing = [f for f in required if not (self.processed / f).exists()]
        if missing:
            raise FileNotFoundError(
                f"Missing split file(s) {missing} in {self.processed}. Run ml.split first."
            )

        y_train = pd.read_csv(self.processed / "y_train.csv")
        y_valid = pd.read_csv(self.processed / "y_valid.csv")
        y_test = pd.read_csv(self.processed / "y_test.csv")

        scaler = StandardScaler()

        y_train_scaled = scaler.fit_transform(y_train)
        y_valid_scaled = scaler.transform(y_valid)
        y_test_scaled = scaler.transform(y_test)

        pd.DataFrame(y_train_scaled, columns=["IDS"]).to_csv(
            self.processed / "y_train_scaled.csv", index=False
        )
        pd.DataFrame(y_valid_scaled, columns=["IDS"]).to_csv(
            self.processed / "y_valid_scaled.csv", index=False
        )
        pd.DataFrame(y_test_scaled, columns=["IDS"]).to_csv(
            self.processed / "y_test_scaled.csv", index=False
        )

        joblib.dump(scaler, Y_SCALER_PATH)

        logger.info("Target scaling completed. Scaler saved to %s", Y_SCALER_PATH)

        return scaler


def main() -> None:
    """CLI entry point: run target scaling."""
    TargetScaler().scale()


if __name__ == "__main__":
    main()
