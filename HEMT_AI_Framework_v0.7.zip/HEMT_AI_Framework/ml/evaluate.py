"""
===========================================================
evaluate.py (ml package)

Thin CLI wrapper around models.evaluate.evaluate_model.

This used to be a separate, duplicated evaluation script
with its own hardcoded paths. It now delegates to the single
canonical implementation in models/evaluate.py so metrics,
plots, and paths never drift between the two.

Author : AmirReza Sadeghi
===========================================================
"""

from config import get_logger
from models.evaluate import evaluate_model

logger = get_logger(__name__)


def main() -> None:
    """CLI entry point: run the canonical evaluation pipeline."""
    metrics = evaluate_model()
    logger.info("Evaluation metrics: %s", metrics)


if __name__ == "__main__":
    main()
