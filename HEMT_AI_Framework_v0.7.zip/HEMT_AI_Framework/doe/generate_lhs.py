"""
=========================================================
generate_lhs.py

Generate Latin Hypercube Sampling (DOE)

Author : AmirReza Sadeghi
=========================================================
"""

from pathlib import Path

import pandas as pd
from scipy.stats import qmc

# =========================================================
# Design Space
# =========================================================

EPS_MIN = 5
EPS_MAX = 80

QF_MIN = 1e11
QF_MAX = 7.5e12

N_SAMPLES = 60

# =========================================================
# Generate LHS
# =========================================================

sampler = qmc.LatinHypercube(
    d=2,
    seed=42
)

sample = sampler.random(n=N_SAMPLES)

# =========================================================
# Scale to Physical Values
# =========================================================

scaled = qmc.scale(
    sample,
    [EPS_MIN, QF_MIN],
    [EPS_MAX, QF_MAX]
)

# =========================================================
# Create DataFrame
# =========================================================

df = pd.DataFrame(
    scaled,
    columns=["EPS", "QF"]
)

# شماره اجرای شبیه‌سازی
df.insert(
    0,
    "Run",
    range(1, len(df) + 1)
)

# وضعیت اجرای TCAD
df["Status"] = "Pending"

# نام فایل لاگ
df["LogFile"] = df["Run"].apply(
    lambda x: f"run{x:03d}.log"
)

# =========================================================
# Save
# =========================================================

OUTPUT_DIR = Path("Data/DOE")

OUTPUT_DIR.mkdir(
    parents=True,
    exist_ok=True
)

OUTPUT_FILE = OUTPUT_DIR / "lhs_design.csv"

df.to_csv(
    OUTPUT_FILE,
    index=False
)

# =========================================================
# Print
# =========================================================

print("=" * 60)
print("LATIN HYPERCUBE DESIGN")
print("=" * 60)
print()

print(df)

print()
print("=" * 60)
print("DOE CREATED SUCCESSFULLY")
print("=" * 60)
print()

print("Samples :", len(df))
print("Saved to:", OUTPUT_FILE)