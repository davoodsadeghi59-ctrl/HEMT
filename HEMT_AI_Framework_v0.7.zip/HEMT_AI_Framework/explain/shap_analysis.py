"""
===========================================================
shap_analysis.py

Explain the ANN using SHAP

Generates the full explainability suite required for the
thesis: summary plot, bar plot, beeswarm plot, waterfall
plot (single-instance explanation), per-feature dependence
plots, and a ranked feature-importance table.

Author : AmirReza Sadeghi
===========================================================
"""

from typing import Dict

import matplotlib
import pandas as pd
import shap
from tensorflow.keras.models import load_model

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from config import BEST_MODEL_PATH, FIGURE_DPI, FIGURE_FACECOLOR, PROCESSED_DIR, RANDOM_SEED, SHAP_DIR, get_logger

logger = get_logger(__name__)


def run_shap_analysis(
    model_path=BEST_MODEL_PATH,
    processed_dir=PROCESSED_DIR,
    results_dir=SHAP_DIR,
    background_size: int = 100,
    waterfall_index: int = 0,
) -> pd.DataFrame:
    """Run the full SHAP explainability suite on the trained ANN.

    Args:
        model_path: Path to the trained ``.keras`` model.
        processed_dir: Directory with the scaled train/test splits.
        results_dir: Directory to save all SHAP artifacts into.
        background_size: Number of training samples used as the SHAP
            background distribution.
        waterfall_index: Index into the test set used for the
            single-instance waterfall plot.

    Returns:
        A DataFrame ranking features by mean absolute SHAP value.

    Raises:
        FileNotFoundError: If the trained model is missing.
    """
    if not model_path.exists():
        raise FileNotFoundError(f"Model not found at {model_path}")

    results_dir.mkdir(parents=True, exist_ok=True)

    X_train = pd.read_csv(processed_dir / "X_train_scaled.csv")
    X_test = pd.read_csv(processed_dir / "X_test_scaled.csv")
    feature_names = list(X_train.columns)

    logger.info("Loading model from %s", model_path)
    model = load_model(model_path)

    background = X_train.sample(min(background_size, len(X_train)), random_state=RANDOM_SEED)

    logger.info("Building SHAP explainer (background=%d samples)", len(background))
    explainer = shap.Explainer(model, background)

    logger.info("Computing SHAP values for %d test samples", len(X_test))
    shap_values = explainer(X_test)

    importance = pd.DataFrame(
        {"Feature": feature_names, "MeanAbsSHAP": abs(shap_values.values).mean(axis=0)}
    ).sort_values(by="MeanAbsSHAP", ascending=False)
    importance.to_csv(results_dir / "feature_importance.csv", index=False)
    logger.info("Feature ranking:\n%s", importance.to_string(index=False))

    _save_summary_plot(shap_values, X_test, results_dir)
    _save_bar_plot(shap_values, results_dir)
    _save_beeswarm_plot(shap_values, results_dir)
    _save_waterfall_plot(shap_values, results_dir, waterfall_index)
    _save_dependence_plots(shap_values, feature_names, results_dir)

    logger.info("SHAP analysis finished. Results saved to %s", results_dir)

    return importance


def _save_summary_plot(shap_values, X_test, results_dir) -> None:
    fig = plt.figure(facecolor=FIGURE_FACECOLOR)
    shap.summary_plot(shap_values, X_test, show=False)
    plt.tight_layout()
    fig.savefig(results_dir / "summary_plot.png", dpi=FIGURE_DPI, facecolor=FIGURE_FACECOLOR)
    plt.close(fig)


def _save_bar_plot(shap_values, results_dir) -> None:
    fig = plt.figure(facecolor=FIGURE_FACECOLOR)
    shap.plots.bar(shap_values, show=False)
    plt.tight_layout()
    fig.savefig(results_dir / "bar_plot.png", dpi=FIGURE_DPI, facecolor=FIGURE_FACECOLOR)
    plt.close(fig)


def _save_beeswarm_plot(shap_values, results_dir) -> None:
    fig = plt.figure(facecolor=FIGURE_FACECOLOR)
    shap.plots.beeswarm(shap_values, show=False)
    plt.tight_layout()
    fig.savefig(results_dir / "beeswarm_plot.png", dpi=FIGURE_DPI, facecolor=FIGURE_FACECOLOR)
    plt.close(fig)


def _save_waterfall_plot(shap_values, results_dir, index: int) -> None:
    # For this single-output regressor, base_values comes back as a
    # length-1 array per sample; shap.plots.waterfall needs a scalar,
    # so build a single-instance Explanation with it squeezed.
    instance = shap.Explanation(
        values=shap_values.values[index],
        base_values=shap_values.base_values[index][0],
        data=shap_values.data[index],
        feature_names=shap_values.feature_names,
    )

    fig = plt.figure(facecolor=FIGURE_FACECOLOR)
    shap.plots.waterfall(instance, show=False)
    plt.tight_layout()
    fig.savefig(results_dir / "waterfall_plot.png", dpi=FIGURE_DPI, facecolor=FIGURE_FACECOLOR)
    plt.close(fig)


def _save_dependence_plots(shap_values, feature_names, results_dir) -> None:
    # Plotted directly with matplotlib rather than shap.plots.scatter:
    # this shap version's Explanation slicer is unreliable once an
    # Explanation has already been reduced to a single feature column,
    # so we work with the raw numpy arrays instead.
    for position, feature in enumerate(feature_names):
        feature_values = shap_values.data[:, position]
        feature_shap = shap_values.values[:, position]

        fig = plt.figure(figsize=(6, 4), facecolor=FIGURE_FACECOLOR)
        plt.scatter(feature_values, feature_shap, alpha=0.6, s=12)
        plt.axhline(0, color="grey", linestyle="--", linewidth=0.8)
        plt.xlabel(f"{feature} (scaled)")
        plt.ylabel(f"SHAP value for {feature}")
        plt.title(f"SHAP Dependence: {feature}")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(
            results_dir / f"{feature}_dependence.png", dpi=FIGURE_DPI, facecolor=FIGURE_FACECOLOR
        )
        plt.close(fig)


def main() -> None:
    """CLI entry point: run SHAP analysis."""
    run_shap_analysis()


if __name__ == "__main__":
    main()
