"""
===========================================================
HEMT-AI Framework
Configuration File

Central source of truth for every path, constant, and
logging setup used across the framework. No module should
hard-code a path or the random seed; import it from here
instead.

Author : AmirReza Sadeghi
Version: 1.1.0
===========================================================
"""

import logging
from pathlib import Path

# ==========================================================
# Project Information
# ==========================================================

PROJECT_NAME = "HEMT-AI Framework"
VERSION = "1.1.0"

# ==========================================================
# Project Paths
# ==========================================================

PROJECT_ROOT = Path(__file__).resolve().parent

# NOTE: the on-disk folder is "Data" (capital D). Using the
# wrong case works by accident on case-insensitive
# filesystems (Windows/macOS) but breaks on Linux/CI.
DATA_DIR = PROJECT_ROOT / "Data"

RAW_LOG_DIR = DATA_DIR / "raw_logs"
DATASET_DIR = DATA_DIR / "datasets"
PROCESSED_DIR = DATA_DIR / "processed"
DOE_DIR = DATA_DIR / "DOE"
MODEL_ARTIFACT_DIR = DATA_DIR / "models"          # scaler.pkl, standard_scaler.pkl live here

TCAD_DIR = PROJECT_ROOT / "tcad"
ML_DIR = PROJECT_ROOT / "ml"
MODELS_DIR = PROJECT_ROOT / "models"
OPTIMIZATION_DIR = PROJECT_ROOT / "optimization"

FIGURE_DIR = PROJECT_ROOT / "figures"
NOTEBOOK_DIR = PROJECT_ROOT / "notebooks"
THESIS_DIR = PROJECT_ROOT / "thesis"
TEST_DIR = PROJECT_ROOT / "tests"

RESULTS_DIR = PROJECT_ROOT / "results"
SHAP_DIR = RESULTS_DIR / "shap"
IMPORTANCE_DIR = RESULTS_DIR / "importance"
OPTIMIZATION_RESULTS_DIR = RESULTS_DIR / "optimization"

# ==========================================================
# Model Artifact Files
# ==========================================================

BEST_MODEL_PATH = PROJECT_ROOT / "best_model.keras"
TRAINING_HISTORY_PATH = PROJECT_ROOT / "training_history.csv"
X_SCALER_PATH = MODEL_ARTIFACT_DIR / "standard_scaler.pkl"
Y_SCALER_PATH = PROCESSED_DIR / "y_scaler.pkl"

# ==========================================================
# Dataset Files
# ==========================================================

RAW_DATASET_PATH = DATASET_DIR / "hemt_dataset.csv"
ML_DATASET_PATH = DATASET_DIR / "hemt_ml_dataset.csv"

# ==========================================================
# Export Options
# ==========================================================

EXPORT_EXCEL = True
EXPORT_CSV = True
EXPORT_PARQUET = False

# ==========================================================
# Device Parameters
# ==========================================================

VDS = 5.0  # Drain-source bias used across all TCAD sweeps [V]

# ==========================================================
# Figure Style
# ==========================================================

FIGURE_DPI = 300
FIGURE_FACECOLOR = "white"

# ==========================================================
# Logging
# ==========================================================

LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"

_LOGGING_CONFIGURED = False


def configure_logging(level: str = LOG_LEVEL) -> None:
    """Configure the root logger once for the whole framework.

    Safe to call multiple times; only the first call has an
    effect, so every module can call it defensively without
    duplicating log handlers.

    Args:
        level: Logging level name (e.g. "INFO", "DEBUG").
    """
    global _LOGGING_CONFIGURED

    if _LOGGING_CONFIGURED:
        return

    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=LOG_FORMAT,
        datefmt=LOG_DATEFMT,
    )

    _LOGGING_CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a module-level logger with the framework's standard setup.

    Args:
        name: Usually ``__name__`` of the calling module.

    Returns:
        A configured :class:`logging.Logger` instance.
    """
    configure_logging()
    return logging.getLogger(name)


# ==========================================================
# Random Seed
# ==========================================================

RANDOM_SEED = 42
